﻿using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MapCamera))]
public class MapCameraEditor : UnityEditor.Editor
{
    public override void OnInspectorGUI()
    {
    }
}
