﻿public interface IAvatarLoader
{
    void ShowPicture();
}
